import React, { useState } from 'react';
import { BarChart3, Bell, Users, RefreshCw, TrendingUp, Target, Calendar, AlertTriangle } from 'lucide-react';
import { clients, transactions, predictions, alertes, opportunites, analysesClients } from './data/mockData';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <RefreshCw className="h-8 w-8 text-blue-600" />
            <h1 className="text-2xl font-semibold text-gray-900">BIAT Forex Prediction</h1>
          </div>
          <nav className="flex space-x-4">
            <button
              onClick={() => setActiveTab('dashboard')}
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                activeTab === 'dashboard'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <BarChart3 className="h-5 w-5 inline-block mr-1" />
              Tableau de Bord
            </button>
            <button
              onClick={() => setActiveTab('clients')}
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                activeTab === 'clients'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Users className="h-5 w-5 inline-block mr-1" />
              Clients
            </button>
            <button
              onClick={() => setActiveTab('opportunites')}
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                activeTab === 'opportunites'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Target className="h-5 w-5 inline-block mr-1" />
              Opportunités
            </button>
            <button
              onClick={() => setActiveTab('alerts')}
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                activeTab === 'alerts'
                  ? 'bg-blue-100 text-blue-700'
                  : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              <Bell className="h-5 w-5 inline-block mr-1" />
              Alertes
            </button>
          </nav>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium text-gray-900">Volume Total</h3>
                  <TrendingUp className="h-5 w-5 text-green-500" />
                </div>
                <p className="mt-2 text-3xl font-semibold">1.25M EUR</p>
                <p className="text-sm text-gray-500">+12% vs mois précédent</p>
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium text-gray-900">Clients Actifs</h3>
                  <Users className="h-5 w-5 text-blue-500" />
                </div>
                <p className="mt-2 text-3xl font-semibold">24</p>
                <p className="text-sm text-gray-500">+3 nouveaux ce mois</p>
              </div>
              <div className="bg-white rounded-lg shadow p-6">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium text-gray-900">Opportunités</h3>
                  <Target className="h-5 w-5 text-purple-500" />
                </div>
                <p className="mt-2 text-3xl font-semibold">8</p>
                <p className="text-sm text-gray-500">350k EUR potentiel</p>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold mb-4">Prévisions des Transactions</h2>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={transactions}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="montant" fill="#3B82F6" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white rounded-lg shadow p-6">
              <h2 className="text-lg font-semibold mb-4">Prochaines Transactions Prévues</h2>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead>
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Client
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date Prévue
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Montant
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Devise
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Probabilité
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Opportunité
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {predictions.map((prediction) => {
                      const client = clients.find((c) => c.id === prediction.clientId);
                      return (
                        <tr key={`${prediction.clientId}-${prediction.datePrevue}`}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                            {client?.nom}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {format(new Date(prediction.datePrevue), 'dd/MM/yyyy', { locale: fr })}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {prediction.montantPrevu.toLocaleString()} {prediction.deviseSourcePrevue}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {prediction.deviseSourcePrevue} → {prediction.deviseTargetPrevue}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {(prediction.probabilite * 100).toFixed(0)}%
                          </td>
                          <td className="px-6 py-4 text-sm text-gray-500">
                            {prediction.opportuniteCommerciale}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'clients' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold">Portefeuille Clients</h2>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead>
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Client
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Segment
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Volume Mensuel
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Score
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Tendance
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {clients.map((client) => {
                      const analyse = analysesClients.find((a) => a.clientId === client.id);
                      return (
                        <tr key={client.id}>
                          <td className="px-6 py-4">
                            <div className="text-sm font-medium text-gray-900">{client.nom}</div>
                            <div className="text-sm text-gray-500">{client.secteurActivite}</div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              client.segment === 'Premium' 
                                ? 'bg-purple-100 text-purple-800'
                                : client.segment === 'Corporate'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-gray-100 text-gray-800'
                            }`}>
                              {client.segment}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {client.volumeMensuelMoyen.toLocaleString()} EUR
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="text-sm text-gray-900">{client.scoreEngagement}</div>
                              <div className={`ml-2 flex-shrink-0 h-2 w-16 rounded-full ${
                                client.scoreEngagement >= 80 
                                  ? 'bg-green-500'
                                  : client.scoreEngagement >= 60
                                  ? 'bg-yellow-500'
                                  : 'bg-red-500'
                              }`}></div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              analyse?.tendanceVolume === 'Hausse'
                                ? 'bg-green-100 text-green-800'
                                : analyse?.tendanceVolume === 'Stable'
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {analyse?.tendanceVolume}
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {clients.map((client) => {
                const analyse = analysesClients.find((a) => a.clientId === client.id);
                return (
                  <div key={client.id} className="bg-white rounded-lg shadow p-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-lg font-medium text-gray-900">{client.nom}</h3>
                        <p className="text-sm text-gray-500">{client.secteurActivite}</p>
                      </div>
                      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                        client.segment === 'Premium'
                          ? 'bg-purple-100 text-purple-800'
                          : 'bg-blue-100 text-blue-800'
                      }`}>
                        {client.segment}
                      </span>
                    </div>
                    
                    <div className="mt-4">
                      <h4 className="text-sm font-medium text-gray-900">Recommandations</h4>
                      <ul className="mt-2 space-y-2">
                        {analyse?.recommandations.map((rec, index) => (
                          <li key={index} className="flex items-start">
                            <Target className="h-5 w-5 text-blue-500 mr-2" />
                            <span className="text-sm text-gray-600">{rec}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-4 grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-500">Potentiel de Croissance</p>
                        <p className="text-lg font-semibold text-gray-900">
                          {(analyse?.potentielCroissance ?? 0 * 100).toFixed(0)}%
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Risque de Perte</p>
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                          analyse?.risquePerte === 'Faible'
                            ? 'bg-green-100 text-green-800'
                            : analyse?.risquePerte === 'Moyen'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-red-100 text-red-800'
                        }`}>
                          {analyse?.risquePerte}
                        </span>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'opportunites' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {opportunites.map((opp) => {
                const client = clients.find((c) => c.id === opp.clientId);
                return (
                  <div key={opp.id} className="bg-white rounded-lg shadow p-6">
                    <div className="flex justify-between items-start">
                      <div>
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                          opp.type === 'Cross-selling'
                            ? 'bg-blue-100 text-blue-800'
                            : opp.type === 'Upselling'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-purple-100 text-purple-800'
                        }`}>
                          {opp.type}
                        </span>
                        <h3 className="mt-2 text-lg font-medium text-gray-900">{client?.nom}</h3>
                      </div>
                      <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                        opp.statut === 'Nouvelle'
                          ? 'bg-green-100 text-green-800'
                          : opp.statut === 'En cours'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-gray-100 text-gray-800'
                      }`}>
                        {opp.statut}
                      </span>
                    </div>
                    
                    <p className="mt-2 text-sm text-gray-600">{opp.description}</p>
                    
                    <div className="mt-4 grid grid-cols-2 gap-4">
                      <div>
                        <p className="text-sm text-gray-500">Potentiel</p>
                        <p className="text-lg font-semibold text-gray-900">
                          {opp.potentielRevenu.toLocaleString()} EUR
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-500">Probabilité</p>
                        <p className="text-lg font-semibold text-gray-900">
                          {(opp.probabiliteSucces * 100).toFixed(0)}%
                        </p>
                      </div>
                    </div>

                    <div className="mt-4 flex items-center text-sm text-gray-500">
                      <Calendar className="h-4 w-4 mr-1" />
                      Suivi prévu: {format(new Date(opp.prochaineSuivi), 'dd/MM/yyyy', { locale: fr })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'alerts' && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg shadow">
              <div className="px-6 py-4 border-b border-gray-200">
                <h2 className="text-lg font-semibold">Alertes et Notifications</h2>
              </div>
              <div className="divide-y divide-gray-200">
                {alertes.map((alerte) => {
                  const client = clients.find((c) => c.id === alerte.clientId);
                  return (
                    <div key={alerte.id} className="px-6 py-4">
                      <div className="flex items-start">
                        <div className="flex-shrink-0">
                          <AlertTriangle className={`h-5 w-5 ${
                            alerte.priorite === 'haute' 
                              ? 'text-red-500'
                              : alerte.priorite === 'moyenne'
                              ? 'text-yellow-500'
                              : 'text-blue-500'
                          }`} />
                        </div>
                        <div className="ml-3 flex-1">
                          <div className="flex items-center justify-between">
                            <p className="text-sm font-medium text-gray-900">{client?.nom}</p>
                            <span className={`px-2 py-1 text-xs font-semibold rounded-full ${
                              alerte.status === 'nouvelle'
                                ? 'bg-red-100 text-red-800'
                                : alerte.status === 'vue'
                                ? 'bg-yellow-100 text-yellow-800'
                                : 'bg-green-100 text-green-800'
                            }`}>
                              {alerte.status}
                            </span>
                          </div>
                          <p className="mt-1 text-sm text-gray-600">{alerte.message}</p>
                          {alerte.actionRecommandee && (
                            <p className="mt-2 text-sm text-blue-600">
                              Action recommandée: {alerte.actionRecommandee}
                            </p>
                          )}
                          <p className="mt-1 text-xs text-gray-500">
                            {format(new Date(alerte.date), 'dd/MM/yyyy HH:mm', { locale: fr })}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}

export default App;