export interface Client {
  id: string;
  nom: string;
  email: string;
  telephone: string;
  derniereTransaction: string;
  segment: 'Premium' | 'Corporate' | 'Standard';
  secteurActivite: string;
  volumeMensuelMoyen: number;
  devisesFrequentes: string[];
  scoreEngagement: number;
}

export interface Transaction {
  id: string;
  clientId: string;
  date: string;
  montant: number;
  deviseSource: string;
  deviseTarget: string;
  taux: number;
  type: 'Spot' | 'Forward' | 'Swap';
  statut: 'Complétée' | 'En cours' | 'Annulée';
  noteClient?: string;
}

export interface Prediction {
  clientId: string;
  datePrevue: string;
  montantPrevu: number;
  deviseSourcePrevue: string;
  deviseTargetPrevue: string;
  probabilite: number;
  raisonPrediction: string[];
  opportuniteCommerciale?: string;
}

export interface Alerte {
  id: string;
  clientId: string;
  type: 'transaction' | 'taux' | 'opportunite' | 'risque';
  message: string;
  date: string;
  status: 'nouvelle' | 'vue' | 'traitée';
  priorite: 'haute' | 'moyenne' | 'basse';
  actionRecommandee?: string;
}

export interface Opportunite {
  id: string;
  clientId: string;
  type: 'Cross-selling' | 'Upselling' | 'Retention' | 'Reactivation';
  description: string;
  potentielRevenu: number;
  probabiliteSucces: number;
  dateCreation: string;
  statut: 'Nouvelle' | 'En cours' | 'Gagnée' | 'Perdue';
  prochaineSuivi: string;
}

export interface AnalyseClient {
  clientId: string;
  tendanceVolume: 'Hausse' | 'Stable' | 'Baisse';
  risquePerte: 'Faible' | 'Moyen' | 'Élevé';
  potentielCroissance: number;
  recommandations: string[];
  scoreValeurClient: number;
}