import { Client, Transaction, Prediction, Alerte, Opportunite, AnalyseClient } from '../types';

export const clients: Client[] = [
  {
    id: '1',
    nom: 'Société ABC',
    email: 'contact@abc.com',
    telephone: '+216 71 234 567',
    derniereTransaction: '2024-03-10',
    segment: 'Corporate',
    secteurActivite: 'Import/Export',
    volumeMensuelMoyen: 250000,
    devisesFrequentes: ['EUR', 'USD'],
    scoreEngagement: 85
  },
  {
    id: '2',
    nom: 'Import Export SARL',
    email: 'finance@importexport.tn',
    telephone: '+216 71 891 234',
    derniereTransaction: '2024-03-12',
    segment: 'Premium',
    secteurActivite: 'Commerce International',
    volumeMensuelMoyen: 500000,
    devisesFrequentes: ['EUR', 'USD', 'GBP'],
    scoreEngagement: 92
  }
];

export const transactions: Transaction[] = [
  {
    id: '1',
    clientId: '1',
    date: '2024-03-10',
    montant: 50000,
    deviseSource: 'EUR',
    deviseTarget: 'TND',
    taux: 3.45,
    type: 'Spot',
    statut: 'Complétée'
  },
  {
    id: '2',
    clientId: '1',
    date: '2024-02-15',
    montant: 75000,
    deviseSource: 'USD',
    deviseTarget: 'TND',
    taux: 3.15,
    type: 'Forward',
    statut: 'Complétée',
    noteClient: 'Couverture importation Q2'
  }
];

export const predictions: Prediction[] = [
  {
    clientId: '1',
    datePrevue: '2024-03-25',
    montantPrevu: 60000,
    deviseSourcePrevue: 'EUR',
    deviseTargetPrevue: 'TND',
    probabilite: 0.85,
    raisonPrediction: [
      'Cycle d\'importation mensuel',
      'Historique transactions similaires',
      'Planning achat communiqué'
    ],
    opportuniteCommerciale: 'Proposer une couverture forward sur 3 mois'
  }
];

export const alertes: Alerte[] = [
  {
    id: '1',
    clientId: '1',
    type: 'transaction',
    message: 'Transaction probable de 60000 EUR prévue le 25/03/2024',
    date: '2024-03-15',
    status: 'nouvelle',
    priorite: 'haute',
    actionRecommandee: 'Contacter le client pour confirmer le besoin et proposer une stratégie de couverture'
  }
];

export const opportunites: Opportunite[] = [
  {
    id: '1',
    clientId: '1',
    type: 'Cross-selling',
    description: 'Proposition de contrat forward EUR/TND sur 6 mois',
    potentielRevenu: 15000,
    probabiliteSucces: 0.75,
    dateCreation: '2024-03-15',
    statut: 'Nouvelle',
    prochaineSuivi: '2024-03-18'
  }
];

export const analysesClients: AnalyseClient[] = [
  {
    clientId: '1',
    tendanceVolume: 'Hausse',
    risquePerte: 'Faible',
    potentielCroissance: 0.25,
    recommandations: [
      'Proposer une augmentation de la ligne de change',
      'Présenter les produits de couverture à terme',
      'Organiser une réunion de revue stratégique'
    ],
    scoreValeurClient: 85
  }
];